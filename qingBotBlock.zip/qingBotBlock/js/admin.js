/* 清歌AI爬虫屏蔽 · 后台交互 */

(function () {
    var cfg = window.QBB || {};
    var defaultRules = cfg.rules || '';
    var defaultBody = cfg.body || '';
    var siteUrl = cfg.site || '';
    var cssUrl = cfg.css || '';

    function trim(text) {
        return String(text).replace(/^\s+|\s+$/g, '');
    }

    function bindCounter(boxId, outId, unit) {
        var box = document.getElementById(boxId);
        var out = document.getElementById(outId);
        if (!box || !out) {
            return null;
        }
        var refresh = function () {
            var rows = box.value.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
            var n = 0;
            for (var i = 0; i < rows.length; i++) {
                if (trim(rows[i]) !== '') {
                    n++;
                }
            }
            out.innerHTML = '共 ' + n + ' ' + unit;
        };
        box.addEventListener('input', refresh);
        refresh();
        return refresh;
    }

    function nudge(box) {
        var ev;
        try {
            ev = new Event('input', { bubbles: true });
        } catch (err) {
            ev = document.createEvent('Event');
            ev.initEvent('input', true, true);
        }
        box.dispatchEvent(ev);
    }

    function sub(text, key, val) {
        return text.replace(new RegExp('\\{' + key + '\\}', 'g'), function () {
            return val;
        });
    }

    function pad(n) {
        return (n < 10 ? '0' : '') + n;
    }

    function nowText() {
        var d = new Date();
        return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' '
            + pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
    }

    function insertAtCursor(box, text) {
        box.focus();
        if (typeof box.selectionStart === 'number') {
            var start = box.selectionStart;
            var end = box.selectionEnd;
            box.value = box.value.slice(0, start) + text + box.value.slice(end);
            var pos = start + text.length;
            box.setSelectionRange(pos, pos);
        } else {
            box.value += text;
        }
    }

    function checkedValue(name, fallback) {
        var el = document.querySelector('input[name="' + name + '"]:checked');
        return el ? el.value : fallback;
    }

    function readState() {
        var code = checkedValue('status', '403');
        var content = checkedValue('content', 'preset');
        return {
            code: code,
            text: code === '200' ? 'OK' : 'Forbidden',
            ok: code === '200',
            content: content,
            custom: content === 'custom'
        };
    }

    function kvRow(key, val) {
        return '<div class="qbb-pv-kv"><span>' + key + '</span><b>' + val + '</b></div>';
    }

    var EMPTY_PAGE = '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">'
        + '<title>{status}</title></head><body></body></html>';

    function preview(tpl) {
        var st = readState();
        var source;
        if (st.content === 'blank') {
            source = EMPTY_PAGE;
        } else if (st.content === 'custom') {
            source = trim(tpl) === '' ? defaultBody : tpl;
        } else {
            source = defaultBody;
        }
        var html = sub(source, 'site', siteUrl);
        html = sub(html, 'url', siteUrl + '114.html');
        html = sub(html, 'ip', '203.0.113.9');
        html = sub(html, 'ua', 'GPTBot/1.0');
        html = sub(html, 'time', nowText());
        html = sub(html, 'code', st.code);
        html = sub(html, 'status', st.text);

        var warn = '';
        if (st.content === 'preset') {
            warn = '<p class="qbb-pv-warn">「内置拦截页」使用插件自带模板，不可修改，所以下面预览的是内置模板本身。</p>';
        } else if (st.content === 'blank') {
            warn = '<p class="qbb-pv-warn">「空白页」不输出任何页面内容，爬虫只会拿到状态码和空 body，所以下面是空白的一片。</p>';
        }

        var shell = '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">'
            + '<title>拦截页预览</title>'
            + (cssUrl ? '<link rel="stylesheet" href="' + cssUrl + '">' : '')
            + '</head><body class="qbb-pv">'
            + '<div class="qbb-pv-hd">'
            + '<div class="qbb-pv-row"><span class="qbb-pv-code ' + (st.ok ? 'qbb-pv-code-ok' : 'qbb-pv-code-no') + '">HTTP/1.1 '
            + st.code + ' ' + st.text + '</span><span class="qbb-pv-label">响应头</span></div>'
            + kvRow('Content-Type', 'text/html; charset=utf-8')
            + kvRow('X-Robots-Tag', 'noindex, nofollow, noarchive')
            + kvRow('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
            + '</div>'
            + '<p class="qbb-pv-tip">状态码属于 HTTP 响应头，页面内容里不显示它，所以下面的页面本身看不到这个数字。'
            + '爬虫收到的是 <b>' + st.code + ' ' + st.text + '</b>。下面是实际输出的页面内容：</p>'
            + warn
            + '<div class="qbb-pv-frame"><iframe id="qbbPV"></iframe></div>'
            + '</body></html>';

        var win = window.open('', '_blank', 'width=1000,height=820,scrollbars=yes');
        if (!win) {
            window.alert('浏览器拦截了预览窗口，请允许弹出窗口后重试。');
            return;
        }
        win.document.open();
        win.document.write(shell);
        win.document.close();

        var frame = win.document.getElementById('qbbPV');
        if (frame) {
            frame.srcdoc = html;
        }
    }

    function escText(text) {
        return String(text)
            .replace(/\[/g, '[lb]')
            .replace(/</g, '[lt]')
            .replace(/>/g, '[gt]')
            .replace(/\r\n|\r|\n/g, '[nl]');
    }

    function packField(boxId, escId) {
        var box = document.getElementById(boxId);
        var esc = document.getElementById(escId);
        if (!box || !esc) {
            return;
        }
        esc.value = escText(box.value);
        box.removeAttribute('name');
    }

    var panes = {
        preset: document.querySelector('.qbb-pane-preset'),
        blank: document.querySelector('.qbb-pane-blank'),
        custom: document.querySelector('.qbb-pane-custom')
    };

    var contentHint = document.getElementById('qbbContentHint');
    var hints = cfg.hints || {};
    var contentInputs = document.querySelectorAll('.qbb-seg-item input[name="content"]');
    var bodyBox = document.getElementById('qbbBody');
    var bodyDirty = false;

    if (bodyBox) {
        bodyBox.addEventListener('input', function () {
            bodyDirty = true;
        });
    }

    function syncContent() {
        var content = checkedValue('content', 'preset');
        for (var key in panes) {
            if (panes[key]) {
                if (key === content) {
                    panes[key].classList.add('qbb-pane-on');
                } else {
                    panes[key].classList.remove('qbb-pane-on');
                }
            }
        }
        if (bodyBox) {
            if (content === 'custom') {
                bodyBox.removeAttribute('readonly');
            } else {
                bodyBox.setAttribute('readonly', 'readonly');
            }
        }
        if (contentHint && hints[content]) {
            contentHint.innerHTML = hints[content];
        }
    }

    Array.prototype.forEach.call(contentInputs, function (radio) {
        radio.addEventListener('change', syncContent);
    });
    syncContent();

    var rulesBox = document.getElementById('qbbRules');
    bindCounter('qbbRules', 'qbbRulesCount', '条');
    bindCounter('qbbWhite', 'qbbWhiteCount', '条');
    bindCounter('qbbBody', 'qbbBodyCount', '行');

    Array.prototype.forEach.call(document.querySelectorAll('#qbbForm button[data-act]'), function (btn) {
        btn.addEventListener('click', function () {
            var box = document.getElementById(btn.getAttribute('data-target'));
            if (!box) {
                return;
            }
            var act = btn.getAttribute('data-act');
            if (act === 'preview') {
                preview(box.value);
                return;
            }
            if (act === 'reset') {
                box.value = defaultRules;
            } else if (act === 'tpl') {
                box.value = defaultBody;
            } else {
                if (!window.confirm('确定清空当前列表吗？')) {
                    return;
                }
                box.value = '';
            }
            nudge(box);
        });
    });

    Array.prototype.forEach.call(document.querySelectorAll('.qbb-chip[data-var]'), function (chip) {
        chip.addEventListener('click', function () {
            var box = document.getElementById('qbbBody');
            if (!box) {
                return;
            }
            insertAtCursor(box, chip.getAttribute('data-var'));
            nudge(box);
        });
    });

    var form = document.getElementById('qbbForm');
    if (form) {
        form.addEventListener('submit', function (e) {
            var on = form.querySelector('input[name="enable"]');
            if (on && on.checked && rulesBox && rulesBox.value.replace(/\s/g, '') === '') {
                if (!window.confirm('拦截规则为空，开启拦截后不会拦截任何请求，仍要保存吗？')) {
                    e.preventDefault();
                    return;
                }
            }
            var keep = document.getElementById('qbbBodyKeep');
            if (bodyBox) {
                if (bodyDirty) {
                    packField('qbbBody', 'qbbBodyEsc');
                    if (keep) {
                        keep.value = '';
                    }
                } else {
                    if (keep) {
                        keep.value = '1';
                    }
                    bodyBox.removeAttribute('name');
                }
            }
            packField('qbbRules', 'qbbRulesEsc');
            packField('qbbWhite', 'qbbWhiteEsc');
        });
    }

    window.console && window.console.info && window.console.info('[qingBotBlock] admin.js v' + (cfg.ver || '?') + ' loaded');
})();
